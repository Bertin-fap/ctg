from ctg.ctggui import AppMain 
app_main = AppMain() 
app_main.mainloop() 
